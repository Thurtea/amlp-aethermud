// Shutdown command

#include <globals.h>

int main(string arg) {
    object user;
    
    user = previous_object();
    
    // Should add security check here
    tell_object(user, "Shutting down server...\n");
    shout("Server shutting down!\n");
    shutdown();
    return 1;
}
