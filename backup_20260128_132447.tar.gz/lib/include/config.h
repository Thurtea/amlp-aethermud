// AMLP-MUD Configuration

#define MUD_NAME "AMLP-MUD"
#define MUD_VERSION "1.0"
#define START_ROOM "/domains/start/room/void"
