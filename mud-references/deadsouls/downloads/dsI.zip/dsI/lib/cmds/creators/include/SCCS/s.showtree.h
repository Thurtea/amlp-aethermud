h23707
s 00008/00000/00000
d D 1.1 96/09/01 19:47:22 nmprd 1 0
c date and time created 96/09/01 19:47:22 by nmprd
e
u
U
f e 0
t
T
I 1
#ifndef l_showtree_h
#define l_showtree_h

mixed cmd(string arg);
string ShowTree(string file, string func, int index);
string GetHelp(string str);

#endif /* l_showtree_h */
E 1
