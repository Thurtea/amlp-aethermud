#ifndef l_showtree_h
#define l_showtree_h

mixed cmd(string arg);
string ShowTree(string file, string func, int index);
string GetHelp(string str);

#endif /* l_showtree_h */
