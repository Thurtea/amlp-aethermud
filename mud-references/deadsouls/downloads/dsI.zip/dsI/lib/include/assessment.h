#ifndef s_assessment_h
#define s_assessment_h

#define INCOMPLETE    1
#define IMPOSSIBLE    2
#define POSSIBLE      3

class assessment {
    int status;
    int last;
}

#endif // s_assessment_h
