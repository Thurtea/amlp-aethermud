#ifndef s_jump_h
#define s_jump_h

#define JUMP_INTO            1
#define JUMP_FROM            2
#define JUMP_THROUGH         3
#define JUMP_OVER            4
#define JUMP_ON              5

#endif /* s_jump_h */
