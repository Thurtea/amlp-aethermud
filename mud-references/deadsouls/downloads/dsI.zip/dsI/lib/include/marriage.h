#ifndef s_marriage_h
#define s_marriage_h

class marriage {
    int WeddingDate;
    int DivorceDate;
    string Spouse;
    string Location;
}

#endif /* s_marriage_h */
