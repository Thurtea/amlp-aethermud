#ifndef s_medium_h
#define s_medium_h

#define MEDIUM_LAND        1
#define MEDIUM_AIR         2
#define MEDIUM_SPACE       3
#define MEDIUM_WATER       4

#endif /* s_medium_h */
