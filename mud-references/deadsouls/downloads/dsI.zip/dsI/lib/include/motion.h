#ifndef __MOTION_H__
#define __MOTION_H__

#define M_LAND           1
#define M_AIR            2
#define M_SEA            3
#define M_MAGIC          4

#endif __MOTION_H__
