#ifndef s_position_h
#define s_position_h

#define POSITION_STANDING           (1 << 1)
#define POSITION_SITTING            (1 << 2)
#define POSITION_LYING              (1 << 3)
#define POSITION_FLYING             (1 << 4)

#endif /* s_position_h */
