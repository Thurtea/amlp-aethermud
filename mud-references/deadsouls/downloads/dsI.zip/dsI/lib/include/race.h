#ifndef s_race_h
#define s_race_h

class stat_cfg {
    int Base;
    int Class;
}

class race_cfg {
    int Fingers;
    mapping Stats;
}

#endif /* s_race_h */
