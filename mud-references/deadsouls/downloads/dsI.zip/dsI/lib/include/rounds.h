#ifndef __ROUNDS_H__
#define __ROUNDS_H__

#define ROUND_UNDEFINED          0
#define ROUND_MELEE              1
#define ROUND_WEAPON             2
#define ROUND_MAGIC              3
#define ROUND_OTHER              4

#endif /* __ROUNDS_H__ */
