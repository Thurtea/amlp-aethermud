#ifndef s_talk_type_h
#define s_talk_type_h

#define TALK_VOID         0
#define TALK_PRIVATE      1
#define TALK_SEMI_PRIVATE 2
#define TALK_LOCAL        3
#define TALK_AREA         4
#define TALK_WORLD        5

#endif /* s_talk_type_h */
