#ifndef s_vision_h
#define s_vision_h

#define VISION_BLIND         0
#define VISION_TOO_DARK      1
#define VISION_DARK          2
#define VISION_DIM           3
#define VISION_CLEAR         4
#define VISION_LIGHT         5
#define VISION_BRIGHT        6
#define VISION_TOO_BRIGHT    7

#endif /* s_vision_h */
