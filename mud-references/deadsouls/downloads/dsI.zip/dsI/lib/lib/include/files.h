#ifndef __FILES_H
#define __FILES_H

string *wild_card(string str);
nomask static int remove_dots(string str);
string query_cwd();

#endif /* __FILES_H */
