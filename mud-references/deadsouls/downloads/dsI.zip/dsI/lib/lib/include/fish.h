#ifndef l_fish_h
#define l_fish_h

static void create();

int eventCatch(object who);

int SetFight(int x);
int GetFight();
string SetFood(string str);
string GetFood();
int SetMass(int x);
int GetMass();

#endif /* l_fish_h */
