#ifndef l_help_h
#define l_help_h

static void create();

static string SetHelp(string str);
string GetHelp(string str);

#endif /* l_help_h */
