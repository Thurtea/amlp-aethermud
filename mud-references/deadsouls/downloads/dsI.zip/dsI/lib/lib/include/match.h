#ifndef l_match_h
#define l_match_h

mixed direct_strike_obj();
mixed eventStrike(object who);
int GetStrikeChance();
static int SetStrikeChance(int x);

#endif /* l_match_h */
