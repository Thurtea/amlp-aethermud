#ifndef __MESSAGES_H__
#define __MESSAGES_H__

static void create();

string SetMessage(string msg, string str);
varargs string GetMessage(string msg, mixed arg);
string GetName();
mapping GetMessages();

#endif /* __MESSAGES_H__ */
