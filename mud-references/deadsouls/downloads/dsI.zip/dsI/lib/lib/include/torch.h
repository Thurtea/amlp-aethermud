#ifndef l_torch_h
#define l_torch_h

static void create();

int GetRadiantLight(int ambient);
string GetShort();
varargs string GetLong(string unused);

#endif /* l_torch_h */
