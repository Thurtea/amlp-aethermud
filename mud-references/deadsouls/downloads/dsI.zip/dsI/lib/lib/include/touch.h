#ifndef l_touch_h
#define l_touch_h

static void create();
varargs mixed SetTouch(mixed arg1, mixed desc);
mapping RemoveTouch(string item);
string GetTouch(string str);
string *GetTouches();

#endif /* l_touch_h */
