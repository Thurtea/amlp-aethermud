#ifndef __VIRTUAL_H__
#define __VIRTUAL_H__

object compile_object(string file);

#endif /* __VIRTUAL_H__ */


