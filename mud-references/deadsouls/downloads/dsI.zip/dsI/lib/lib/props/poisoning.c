/*    /lib/props/poisoning.c
 *    From the Dead Souls V Object Library
 *    Things that can have poison
 *    Created by Descartes of Borg 970101
 *    Version: %A%
 *    Last modified: %D%
 */

