/*    /lib/chair.c
 *    From the Dead Souls V Object Library
 *    A thing you can sit in
 *    Created by Descartes of Borg 961221
 *    Version: @(#) chair.c 1.1@(#)
 *    Last modified: 96/12/21
 */

#include <lib.h>

inherit LIB_ITEM;
inherit LIB_SIT;

/* Nothing else needs to happen here */
