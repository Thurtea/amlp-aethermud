#ifndef l_create_h
#define l_create_h

mixed cmd(string args);
static void CreateRoom(string file, string args);
string GetHelp(string str);

#endif /* l_create_h */

