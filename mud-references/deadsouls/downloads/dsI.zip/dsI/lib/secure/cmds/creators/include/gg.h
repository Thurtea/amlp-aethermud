#ifndef l_gg_h
#define l_gg_h

mixed cmd(string args);
string GetHelp(string str);

#endif /* l_gg_h */
