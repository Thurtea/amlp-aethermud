#ifndef l_more_h
#define l_more_h

mixed cmd(string args);
string GetHelp(string str);

#endif /* l_more_h */
