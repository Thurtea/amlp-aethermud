#ifndef l_players_h
#define l_players_h

static void create();
varargs int RemovePlayer(string str);

#endif /* l_players_h */
