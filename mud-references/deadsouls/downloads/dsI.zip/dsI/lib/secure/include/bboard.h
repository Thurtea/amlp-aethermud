#define BBOARD_DIR 		"/adm/save/boards/"
#define BBOARD_EDIT		"/tmp/bb/"

#define BBOARD_OK		0
#define BAD_DATA		1
#define INVALID_MSG		2
#define ILLEGAL_ACCESS		3
#define EDIT_ABORT		4
