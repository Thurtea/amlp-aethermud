#ifndef __LIB_CLEAN_H__
#define __LIB_CLEAN_H__

#define NEVER_AGAIN             0
#define TRY_AGAIN_LATER         1

#endif /* __LIB_CLEAN_H__ */
