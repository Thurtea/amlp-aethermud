#define JUSTICES ({ "niteraven", "bess", "pianoman", "yildor" })

#define MAYOR ({ "annie" })

#define TREASURER ({ "topknot" })

#define POLICECOM ({ "sluggo" })

#define SECRETARY ({ "brunoer" })
 
#define COUNCIL ({ "bess", "moonstar", "sluggo", "turk", "katana", "mina",\
                   "yildor", "pianoman", "topknot", "niteraven", "brunoer",\
		   "hades", "annie" })
 
#define MAGE_COUNCIL ({ "moonstar" })
 
#define MONK_COUNCIL ({ "bess" })
 
#define ROGUE_COUNCIL ({ "turk" })
 
#define CLERIC_COUNCIL ({ "katana" })
 
#define FIGHTER_COUNCIL ({ "sluggo" })
 
#define KATAAN_COUNCIL ({ "mina" })
