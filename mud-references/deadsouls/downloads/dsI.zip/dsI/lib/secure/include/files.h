#define FILE_FAQ "/news/faq"
