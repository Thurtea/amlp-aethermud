#define I_NORMAL 0
#define I_NOECHO 1
#define I_NOESC  2
