#ifndef __IIPS_H 
#define __IIPS_H 
 
#include <dirs.h> 
 
#define POSTAL_ID              "imaginary mailer" 
 
#endif /* __IIPS_H */ 
