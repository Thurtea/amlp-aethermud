#ifndef s_link_h
#define s_link_h

class char_link {
    string Email;
    string *Secondaries;
    string LastOnWith;
    int LastOnDate;
}

#endif /* s_link_h */
