#ifndef __POST_H 
#define __POST_H 
 
#include <dirs.h> 
 
#define POSTAL_ID              "imaginary mailer" 
#define POSTAL_PROMPT          "% " 
#define POSTAL_USER_HELP       DIR_USER_HELP+"/postal" 
#define POSTAL_CREATOR_HELP    DIR_CREATOR_HELP+"/postal" 
 
#endif /* __POST_H */ 
