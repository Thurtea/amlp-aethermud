#ifndef s_pov_h
#define s_pov_h

#define POV_SUBJECT     1
#define POV_TARGET      2
#define POV_OBSERVER    3

#endif /* s_pov_h */
