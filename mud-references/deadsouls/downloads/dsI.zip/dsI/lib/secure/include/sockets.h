#ifndef s_sockets_h
#define s_sockets_h

#include <lib.h>

#define SOCKET_HTTP      DIR_SECURE_LIB "/net/http"
#define SOCKET_RCP       DIR_SECURE_LIB "/net/rcp"

#endif /* s_sockets_h */
