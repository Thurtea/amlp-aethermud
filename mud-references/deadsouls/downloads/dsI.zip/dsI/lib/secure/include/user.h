#ifndef s_user_h
#define s_user_h

#include <dirs.h>

#define LIB_AUTOSAVE       DIR_USER  "/autosave"

#endif /* s_user_h */
