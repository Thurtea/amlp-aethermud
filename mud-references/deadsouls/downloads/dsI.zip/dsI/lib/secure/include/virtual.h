#ifndef s_virtual_h
#define s_virtual_h

#define LIB_VIRT_LAND    DIR_VIRT "/virt_land"
#define LIB_VIRT_MAP     DIR_VIRT "/virt_map"
#define LIB_VIRT_SKY     DIR_VIRT "/virt_sky"
#define LIB_VIRTUAL      DIR_VIRT "/virt_std"

#endif /* s_virtual_h */
