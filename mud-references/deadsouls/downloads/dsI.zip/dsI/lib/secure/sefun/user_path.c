string user_path(string name)
{
   return ("/realms/"+name+"/");
}

