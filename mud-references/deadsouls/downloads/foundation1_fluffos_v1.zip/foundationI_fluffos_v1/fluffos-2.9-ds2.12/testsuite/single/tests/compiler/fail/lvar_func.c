void foo() {
    int x;
    (: x :);
}
