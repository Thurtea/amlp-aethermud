class foo {
    void x;
}
