void do_tests() {
    ASSERT(!receive(""));
    ASSERT(!receive("recieve_test"));
}
