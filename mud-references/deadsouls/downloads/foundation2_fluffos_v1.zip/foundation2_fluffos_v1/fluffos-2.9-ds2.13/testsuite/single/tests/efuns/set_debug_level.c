void do_tests() {
#ifdef __DEBUG_MACRO__
    set_debug_level(10);
    set_debug_level(0);
#endif
}
