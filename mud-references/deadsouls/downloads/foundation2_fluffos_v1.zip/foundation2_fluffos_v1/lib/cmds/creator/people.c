/*    /cmd *    from Foundation II
 *    a listing of users for creators and ambassadors
 *    created by Descartes of Borg 940724
 */

#include <lib.h>
#include <localtime.h>
#include <config.h>
#include <dirs.h>
#include <daemons.h>

inherit LIB_DAEMON;

static private int *__SortFlags;

static private string query_time();

int cmd(string str) {
    object *who, *display;
    string *args;
    string msg, tmp;
    int i, maxi, aflag, bflag, cflag, eflag, gflag, hflag, lflag, mflag;
    int nflag, pflag, rflag, sflag, uflag;

    if(!str || str == "" || strlen(str) == 1 || str[0] != '-') args = ({});
    else args = explode(str[1..strlen(str)-1], "");
    i = sizeof(args);
    while(i--) {
        switch(args[i]) {
            case "a": aflag = 1; break; /* list arches */
            case "b": bflag = 1; break; /* list ambassadors */
            case "c": cflag = 1; break; /* list creators */
            case "e": eflag = 1; break; /* sort by race */
            case "g": gflag = 1; break; /* sort by age */
            case "h": hflag = 1; break; /* list high mortals */
            case "l": lflag = 1; break; /* sort by level */
            case "m": mflag = 1; break; /* page through more */
            case "n": nflag = 1; break; /* list newbies */
            case "p": pflag = 1; break; /* list regular mortals */
            case "r": rflag = 1; break; /* sort by realm location */
            case "s": sflag = 1; break; /* sort by class */
            case "u": uflag = 1; break; /* list undead */
        }
    }
    who = filter(users(), "filter_invis", this_object());
    if(!aflag && !bflag && !cflag && !hflag && !nflag && !pflag && !uflag)
      display = who;
    else {
        display = ({});
        if(aflag) display += filter(who, "filter_arches", this_object());
        if(bflag) display += filter(who, "filter_ambass", this_object());
        if(cflag) display += filter(who, "filter_cres", this_object());
        if(hflag) display += filter(who, "filter_hms", this_object());
        if(nflag) display += filter(who, "filter_newbie", this_object());
        if(pflag) display += filter(who, "filter_mortal", this_object());
        if(uflag) display += filter(who, "filter_undead", this_object());
        display = distinct_array(display);
    }
    if(!eflag && !gflag && !lflag && !rflag && !sflag) 
      maxi = sizeof(display=sort_array(display,"general_sort",this_object()));
    else {
        __SortFlags = ({ eflag, gflag, lflag, rflag, sflag });
        maxi = sizeof(display = sort_array(display,"special_sort",this_object()));
    }
    msg = implode(map_array(display, "map_info", this_object()), "\n");
    msg = "------------------------------------------------------------------"
      "--------\n"+center(maxi+" people in current sort", 25)+
      center(query_time(), 50)+"\n--------"
      "------------------------------------------------------------------\n" +
      msg+"\n------------------------------------------------------------------"
      "--------\n"+center(mud_name(), 75);
    if(mflag) this_player()->more(explode(msg, "\n"), "system");
    else message("system", msg, this_player());
    return 1;
}

static int filter_invis(object ob) {
    if(!((int)ob->GetKeyName())) return 0;
    if(!((int)ob->GetInvis(this_player()))) return 1;
    if(archp(this_player())) return 1;
    if(archp(ob)) return 0;
    return 1;
}

static int filter_arches(object ob) { return archp(ob); }

static int filter_ambass(object ob) { return ambassadorp(ob); }

static int filter_cres(object ob) { return (creatorp(ob) && !archp(ob)); }

static int filter_hms(object ob) { return high_mortalp(ob); }

static int filter_newbie(object ob) {
    return (!creatorp(ob) && !ambassadorp(ob) && (MAX_NEWBIE_LEVEL >=
      (int)ob->query_level()));
}

static int filter_mortal(object ob) {
    if(creatorp(ob) || high_mortalp(ob) || ambassadorp(ob)) return 0;
    if((int)ob->query_level() <= MAX_NEWBIE_LEVEL) return 0;
    return 1;
}

static int filter_undead(object ob) { return (int)ob->query_ghost(); }

static int general_sort(object alpha, object beta) {
    int x, y;

    if(archp(alpha)) {
        if(!archp(beta)) return -1;
        else return strcmp((string)alpha->GetCapName(), 
          (string)beta->GetCapName());
    }
    else if(archp(beta)) return 1;
    if(creatorp(alpha)) {
        if(!creatorp(beta)) return -1;
        else return strcmp((string)alpha->GetCapName(),
          (string)beta->GetCapName());
    }
    else if(creatorp(beta)) return 1;
    if(ambassadorp(alpha)) {
        if(!ambassadorp(beta)) return -1;
        else return strcmp((string)alpha->GetCapName(),
          (string)beta->GetCapName());
    }
    else if(ambassadorp(beta)) return 1;
    if((x = (int)alpha->query_level()) > (y = (int)beta->query_level()))
      return -1;
    else if(x < y) return 1;
    else return strcmp((string)alpha->GetCapName(),
      (string)beta->GetCapName());
}

static int special_sort(object alpha, object beta) {
    string a, b;
    int x, y;

    if(__SortFlags[4]) {
        if((a=(string)alpha->query_class())!=(b=(string)beta->query_class())) {
            if(!a) a = "zzzz";
            if(!b) b= "zzzz";
            return strcmp(a, b);
        }
    }
    if(__SortFlags[0]) {
        if((a=(string)alpha->query_race()) != (b=(string)beta->query_race())) {
            if(!a) a = "zzzz";
            if(!b) b = "zzzz";
            return strcmp(a, b);
        }
    }
    if(__SortFlags[3]) {
        if((a = file_name(environment(alpha))) != 
          (b = file_name(environment(beta)))) return strcmp(a, b);
    }
    if(__SortFlags[2]) {
        if((x = (int)alpha->query_level()) != (y=(int)beta->query_level())) {
            if(x > y) return -1;
            else return 1;
        }
    }
    if(__SortFlags[1]) {
        if((x = (int)alpha->GetAge()) != (y = (int)beta->GetAge())) {
            if(x > y) return -1;
            else return 1;
        }
    }
    return 0;
}

static string map_info(object ob) {
    string age, nom, blk, lev, ip, env, idle;
    int x;

    x = (int)ob->GetAge();
    if(x > 86400) age = sprintf("%:-2d D", x/86400);
    else if(x > 3600) age = sprintf("%:-2d h", x/3600);
    else age = sprintf("%:-2d m", x/60);
    nom = (string)ob->GetCapName();
    if((int)ob->GetInvis()) nom = "("+nom+")";
    if(in_edit(ob) || in_input(ob)) nom = "["+nom+"]";
    if(creatorp(ob)) {
        if((int)ob->GetBlocked("all")) blk = "ACG";
        else {
            if((int)ob->GetBlocked("cre")) blk = " C";
            else blk = "  ";
            if((int)ob->GetBlocked("gossip")) blk += "G";
            else blk += " ";
        }
    }
    else blk = "   ";
    if(!(x = (int)ob->query_level())) lev = "-";
    else lev = x+"";
    if((x = query_idle(ob)) < 60) idle = "";
    else if(x >= 3600) idle = sprintf("%:-3d h", x/3600);
    else idle = sprintf("%:-2d m", x/60);
    ip = query_ip_name(ob);
    if(!environment(ob)) env = "no environment";
    else env = file_name(environment(ob));
    if(!strsrch(env, REALMS_DIRS)) 
      env = "~" + env[strlen(REALMS_DIRS)+3..];
    else if(!strsrch(env, DOMAINS_DIRS))
      env = "^"+env[strlen(DOMAINS_DIRS)+1..strlen(env)-1];
    return sprintf("%:-5s %:-2s %:-17s %:-15s %:-5s %:-3s %:-22s",
      age, lev, nom, ip, idle, blk, env);
}

static private string query_time() {
    string tzone;
    int x;

    tzone = (string)this_player()->GetTimeZone() || localtime(time())[LT_ZONE];
    x = (int)TIME_D->GetOffset(tzone) * 3600;
    return tzone + " time is: " + ctime(time() + x);
}
    
void help() {
    message("help", "Syntax: people [-abceghlmnprsu]\n\n"
      "Gives you a listing of people on "+mud_name()+".  Output is "
      "formatted into columns with the following meanings:\n"
      "    amount of time spent total on "+mud_name()+"\n"
      "    level\n"
      "    name\n"
      "    address from which the person is connecting\n"
      "    amount of time idle\n"
      "    blocking information, if any... A is all, C cre, G gossip\n"
      "    current environment file name\n\n"
      "Command flags have the following meanings:\n"
      "    -a list all arches\n"
      "    -b list all ambassadors\n"
      "    -c list all non-arch creators\n"
      "    -e sort the listing by race\n"
      "    -g sort the listing by age\n"
      "    -h list all high mortals\n"
      "    -l sort the listing by level\n"
      "    -m pipe the listing through the more pager\n"
      "    -n list all newbies\n"
      "    -p list all non-newbie and non-high mortal mortals\n"
      "    -r sort the listing by current environment\n"
      "    -s sort the listing by class\n"
      "    -u list all undead people\n\n"
      "People in the editor or in mail or posting will be marked with [].  "
      "People who are invisible to others, but not to you will be marked "
      "with ().  The default sort is by arch, then by creator, then by "
      "ambassador, then by level.  You can perform multiple sorts, but "
      "you cannot change the priority.  Sorts priority is: class, race, "
      "realm, level, age.  You can also include multiple groups in your "
      "listing.\n\nSee also: who, users", this_player());
}
