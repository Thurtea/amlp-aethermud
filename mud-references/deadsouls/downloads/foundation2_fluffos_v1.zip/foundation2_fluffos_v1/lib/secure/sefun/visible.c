varargs int visible( object detectee_obj, object detector_obj ) {
    return 0;
/* this function is not quite working without uid's
*/
}
