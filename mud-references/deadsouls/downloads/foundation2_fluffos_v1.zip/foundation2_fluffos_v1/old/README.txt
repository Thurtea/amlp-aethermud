	      The Foundation II Object Library for MudOS
		   Alpha 1 for Beta 2 of Release 3
			Released 30 April 1996
		 Copyright (c) 1994-1996 George Reese

This release is an update for Foundation IIr1, and perhaps the last
actual release before the major overhaul which will be Foundation III.

The instructions for installing the Foundation II Object Library are
available via WWW at:
http://www.imaginary.com/LPC/Foundation/Installation.html
Text instructions are also included with this package, however the web
site is always current, whereas the documentation contained herein may
be out of date.

In general, Foundation documentation sucks right now.  Please excuse
the lack of it.

A mailing list for reporting bugs and general discussion for the
Foundation Object library can be joined by mailing
majordomo@imaginary.com.  Stick the words:
	subscribe foundation-mudlib
in the body of the mail.  To send to the list, send mail to
foundation-mudlib@imaginary.com.

George Reese
borg@imaginary.com
28 April 1996
