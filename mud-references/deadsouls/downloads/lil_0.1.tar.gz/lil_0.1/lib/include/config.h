/*
 * if "global include file" is specified in the config file, this header
 * file is automatically included by all objects; otherwise, you have to
 * #include it manually
 */
#ifndef __CONFIG_H__
#define __CONFIG_H__

#endif
