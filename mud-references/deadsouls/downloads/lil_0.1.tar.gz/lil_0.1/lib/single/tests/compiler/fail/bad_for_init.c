void foo() {
    for (int x += 1; ; ) ;
}
    
