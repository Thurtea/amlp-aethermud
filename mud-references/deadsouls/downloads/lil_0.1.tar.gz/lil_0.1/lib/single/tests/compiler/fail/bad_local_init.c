void foo() {
    int x += 1;
}
