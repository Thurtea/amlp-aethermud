TYPETEST

void foo() {
    return 1;
}
