void foo(mixed x) {
    switch(x) {
    case 1 / 0:
    }
}
