void foo(int x) {
    int x;
}
