class foo x;
