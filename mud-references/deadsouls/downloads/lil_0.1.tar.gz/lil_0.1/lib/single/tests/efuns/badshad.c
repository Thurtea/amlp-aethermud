void create(int arg) {
    if (arg) {
#ifndef __NO_SHADOWS__
	ASSERT(catch(shadow(previous_object())));
	destruct(this_object());
#endif
    }
}

void i_am_bad() {
}
