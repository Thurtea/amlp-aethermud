inherit "/single/tests/efuns/inh0.c";
