void foo() {}

void do_tests() {
    // We can only set up one input_to, which makes this hard to test
    // exhaustively
    if (this_player())
        ASSERT(input_to((: foo, "bazz" :), 1, "bar"));
}
