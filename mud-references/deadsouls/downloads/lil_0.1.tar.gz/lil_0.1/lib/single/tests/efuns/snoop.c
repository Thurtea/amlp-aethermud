void do_tests() {
    // maybe when it is possible for arbitrary objects to snoop.
}
