/* Do not remove the headers from this file! see /USAGE for more info. */

string query_pronoun(){  return "he";}

string query_reflexive(){ return "himself"; }

string query_subjective(){ return query_pronoun(); }

string query_objective(){ return "him"; }

string query_possessive(){ return "his"; }

string query_named_possessive(){  return "Somebody's"; }

string a_short(){ return "Somebody"; }

string short(){ return "Somebody"; }

string the_short(){ return "Somebody"; }
