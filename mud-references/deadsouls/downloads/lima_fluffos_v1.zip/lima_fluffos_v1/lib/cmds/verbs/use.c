/* Do not remove the headers from this file! see /USAGE for more info. */

inherit VERB_OB;

void create() {
    add_rules( ({ "OBJ" }) );
}
