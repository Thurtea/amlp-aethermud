/* Do not remove the headers from this file! see /USAGE for more info. */

inherit VERB_OB;


void do_wait()
{
    write("Do I have to do EVERYTHING for you?\n");
}
void create() {
    add_rules( ({ "" }) );
}

