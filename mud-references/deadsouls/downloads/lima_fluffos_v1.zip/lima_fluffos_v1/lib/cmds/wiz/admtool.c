/* Do not remove the headers from this file! see /USAGE for more info. */

//:COMMAND
//USAGE admtool
//
//Invokes the menu-driven admtool, for code admin tasks.

inherit CMD;

private void main(string arg)
{
  new("/obj/admtool/admtool2");
}
