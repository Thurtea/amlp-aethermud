/* Do not remove the headers from this file! see /USAGE for more info. */

//:COMMAND
//USAGE null
//
//Does nothing at all .....

inherit CMD;

private void main()
{
}
