/* Do not remove the headers from this file! see /USAGE for more info. */

//:COMMAND
//USAGE tasktool
//
//Invokes the menu-driven tasktool system,
//which is intended as a "todo" handler.

inherit CMD;

private void main(string arg)
{
  new(TASKTOOL);
}
