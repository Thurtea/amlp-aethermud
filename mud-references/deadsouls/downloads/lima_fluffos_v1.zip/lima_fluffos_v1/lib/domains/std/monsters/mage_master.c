/* Do not remove the headers from this file! see /USAGE for more info. */

inherit STOCK_MASTER;

void create()
{
    ::create("stock-mage");
}
