/* Do not remove the headers from this file! see /USAGE for more info. */

inherit LANTERN;

void setup() {
    set_adj("brass");
    set_long("Somehow, this brass lantern looks vaguely familiar.\n");
 }
