This is The LPUniversity mudlib in a package that
is easy to install and generally works for most
people. I, Cratylus, am not responsible for anything
that it does. Praise or curse Tacitus and, preferably,
don't ever remind me I put this bundle together.

To install, follow the instructions in the appropriate
INSTALL* file.

-Cratylus @ Dead Souls
January 2008

PS The old verbiage is in the etc/ folder.
