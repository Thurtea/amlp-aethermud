#!/bin/sh
# Tacitus @ LPUniversity
# 17-OCT-05
# Script to delete all pfiles quickly.

cd ../lib/data/users/
rm -rf a/* b/* c/* d/* e/* f/* g/* h/* i/* j/* k/* l/* m/* n/* o/* p/* q/* r/* s/* t/* u/* v/* w/* x/* y/* z/*

