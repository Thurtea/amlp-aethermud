void do_tests() {
#ifndef __NO_ADD_ACTION__
    notify_fail("foo");
    notify_fail((: write("hi!\n") :));
#endif
}
