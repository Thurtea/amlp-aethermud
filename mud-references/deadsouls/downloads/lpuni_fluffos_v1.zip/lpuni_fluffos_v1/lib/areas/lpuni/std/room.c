inherit ROOM;
