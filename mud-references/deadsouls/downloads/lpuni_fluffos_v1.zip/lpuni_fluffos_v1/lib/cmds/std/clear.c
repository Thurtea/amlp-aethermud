/* clear.c
Icoz @ LPUniversity
21-MAY-06
Standard command

*/

int main(string str)
{
    write("%^CLEAR%^\n");
    return 1;
}

string help()
{
    return(HIW + "SYNTAX: " + NOR + "clear\n\n"
    "This command clears the screen\n");
}
