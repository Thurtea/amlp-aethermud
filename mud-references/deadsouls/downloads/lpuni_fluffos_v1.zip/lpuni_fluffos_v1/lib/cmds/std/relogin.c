/* relogin.c

 Tacitus @ LPUniversity
 12-JUNE-06
 Relogin command

*/

int main()
{
    LOGIN_OB->relogin();
    return 1;
}