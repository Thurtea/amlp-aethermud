// Directory definitions

#define DIR_STD "/std"
#define DIR_CMDS "/cmds"  
#define DIR_DAEMON "/daemon"
#define DIR_DOMAINS "/domains"
#define DIR_SECURE "/secure"
#define DIR_SAVE "/save"
#define DIR_LOG "/log"
#define DIR_DATA "/data"
