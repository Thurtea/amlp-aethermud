#ifndef QSORT_H
#define QSORT_H

/*
 * qsort.c
 */
void quickSort (void *, int, int, int (*) ());

#endif
