#ifndef RECLAIM_H
#define RECLAIM_H

/*
 * reclaim.c
 */
int reclaim_objects (void);

#endif
