#include <globals.h>

int
main(string file)
{
	// need to call resolve_path() and query_cwd()
	rm(file);
	return 1;
}
