void foo() {
    foreach (x in ({})) ;
}
