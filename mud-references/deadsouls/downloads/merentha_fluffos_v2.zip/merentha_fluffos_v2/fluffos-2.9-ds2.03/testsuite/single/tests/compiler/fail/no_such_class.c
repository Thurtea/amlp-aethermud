void foo() {
    new(class foo);
}
