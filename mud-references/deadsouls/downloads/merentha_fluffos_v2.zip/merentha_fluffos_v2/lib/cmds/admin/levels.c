// Petrarch
// Merentha Lib 1.0
// <levels>

#include <daemons.h>

int command() {
string *tmp=({});
int i=0;
  while(i++<50) 
    tmp+=({arrange_string(""+i, 4)+":"+ADVANCE_D->query_needed_exp(i)});
  message("command", format_page(tmp,3), this_player());
  return 1;
}
