// Petrarch
// Merentha Lib 1.0
// <shutdown>

int command() {
  shutdown();
  return 1;
}

