// Petrarch
// Merentha Lib 1.0
// <quit>

string help() {
return "Syntax: quit\n\nThis command allows you to leave the game. \
Your character will automatcilly be saved when you do.\n\nSee also: \
save";
}

varargs int command(string str) {
  return 0;
}

