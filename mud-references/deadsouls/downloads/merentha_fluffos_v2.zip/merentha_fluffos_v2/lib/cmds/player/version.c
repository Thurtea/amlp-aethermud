// Petrarch
// Merentha Lib 1.0
// <version>

string help() {
  return "Syntax: version\n\nReturns the version of the software running.";
}

int command() {
  message("command", "MUD: "+mud_name()+"\n\
Mudlib: "+mudlib()+"\n\
Driver: "+driver(), this_player());
  return 1;
}
