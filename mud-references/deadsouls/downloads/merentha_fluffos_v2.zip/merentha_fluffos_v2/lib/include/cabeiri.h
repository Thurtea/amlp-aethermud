#ifndef __CABEIRI__
#define __CABEIRI__

#define ROOMS /domains/Cabeiri/
#define HOUSE /domains/Cabeiri/houses/

#endif

