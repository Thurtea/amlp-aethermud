#ifndef __CHAT_H__
#define __CHAT_H__

#define MIS_CHANNELS         ({"intermer","imud_code","dchat","dead_test4"})

#endif

