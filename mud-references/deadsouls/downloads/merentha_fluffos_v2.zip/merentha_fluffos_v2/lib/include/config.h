#ifndef __CONFIG_H__
#define __CONFIG_H__

#define MUD_LOCKED 0

#endif

