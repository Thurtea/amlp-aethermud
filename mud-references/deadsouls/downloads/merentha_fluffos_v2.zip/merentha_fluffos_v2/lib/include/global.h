#ifndef __GLOBAL_H__
#define __GLOBAL_H__

#include <daemons.h>

#define __REBOOTING__         REBOOT_D->query_rebooting()

#endif

