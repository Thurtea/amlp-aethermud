#ifndef __LPC_TYPES_H_
#define __LPC_TYPES_H_

#define INT             "int"
#define STRING          "string"
#define ARRAY           "array"
#define OBJECT          "object"
#define MAPPING         "mapping"
#define FUNCTION        "function"
#define FLOAT           "float"

#endif
