#ifndef __MATH_H__
#define __MATH_H__

#define MIN(a,b,c,d) (a<=b&&a<=c&&a<=d?a:(b<=c&&b<=d?b:(c<=d?c:d)))
#define MAX(a,b,c,d) (a>=b&&a>=c&&a>=d?a:(b>=c&&b>=d?b:(c>=d?c:d)))

#endif

