#ifndef __MONEY_H__
#define __MONEY_H__

#define __CURRENCY_TYPES ({"gold"})

#endif

