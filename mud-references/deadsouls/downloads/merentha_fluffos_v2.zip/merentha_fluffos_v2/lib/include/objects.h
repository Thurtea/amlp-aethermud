#ifndef __OBJECTS_H__
#define __OBJECTS_H__

#define LOGIN_OB        "/std/login/login"
#define CORPSE_OB       "/std/obj/corpse"
#define MONEY_OB        "/std/obj/money"
#define VOID_OB                "/domains/ROOMS/void"

#endif
