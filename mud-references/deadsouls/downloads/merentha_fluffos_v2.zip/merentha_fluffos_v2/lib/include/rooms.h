#ifndef __ROOMS_H__
#define __ROOMS_H__

#define DEATH_ROOM "/domains/ROOMS/setter"
#define SETTER_ROOM "/domains/ROOMS/setter"
#define SETTER_ROOM_2 "/domains/ROOMS/setter2"
#define START_ROOM "/domains/Cabeiri/square"
#define VOID_ROOM "/domains/ROOMS/void"

#endif

