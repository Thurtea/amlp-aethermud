int file_exists(string str) { return (file_size(str) > -1); } 
