void log_file(string file, string mess) {
  write_file("/log/"+file, mess);
}

