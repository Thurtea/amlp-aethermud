#include <math.h>

varargs int min(mixed a,mixed b,mixed c,mixed d) {
  return MIN(a,b,c,d);
}

varargs int max(mixed a,mixed b,mixed c,mixed d) {
  return MAX(a,b,c,d);
}

