int convert_money(int val, string money) {
  return val;
}

