string mud_name() { return MUD_NAME; }
string mudlib() { return "Merentha 1.2.0"; }
string driver() { return __VERSION__; }
int query_host_port() { return __PORT__; }
