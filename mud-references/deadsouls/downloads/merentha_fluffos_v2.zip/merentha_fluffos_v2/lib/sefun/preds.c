varargs int admin_p(object ob) {
  if(!ob) return 0;
  if(ob->query_position()!="player") return 1;
  return 0;
}

