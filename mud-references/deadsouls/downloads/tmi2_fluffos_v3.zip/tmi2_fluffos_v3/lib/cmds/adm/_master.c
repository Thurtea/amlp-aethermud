#include <mudlib.h>
inherit DAEMON;

int cmd_master() {
  destruct(master());
  file_size("???");
  write("Ok.\n");
  return 1;
}

string help()
{
  return( ""+
"Syntax: master\n"+
"Effect: Updates the master object.\n"+
  "" );
}
