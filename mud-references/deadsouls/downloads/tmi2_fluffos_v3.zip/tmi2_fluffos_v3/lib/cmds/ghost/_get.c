 
//	File	:  /cmds/ghost/_get.c
//	Creator	:  Watcher@TMI  (04/03/93)
//
//	Yet another filler command for ghosts. :)

#include <mudlib.h>

inherit DAEMON ;

int cmd_get() {

   write("Your ghostly hands cannot possibly pick anything up.\n");

return 1; }
 
