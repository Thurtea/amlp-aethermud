 
//	File	:  /cmds/ghost/_help.c
//	Creator	:  Watcher@TMI  (04/10/93)
//
//	Since ghost have the same help access as normal users do,
//	simply pass the request onto the standard help command.
 
#include <mudlib.h>
#include <commands.h>
 
inherit DAEMON ;

int cmd_help(string str) {  return (int)CMD_HELP->cmd_help(str);  }
 
