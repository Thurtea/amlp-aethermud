 
//	File	:  /cmds/ghost/_ignore.c
//	Creator	:  Watcher@TMI-2  (04/11/93)
//
//	Ghosts are people too ... sorta ... so they should be allowed
//  	to ignore obnoxious people too. :)

#include <mudlib.h>
#include <commands.h>

inherit DAEMON ;

int cmd_ignore(string str) {  return (int)CMD_IGNORE->cmd_ignore(str);  }
 
