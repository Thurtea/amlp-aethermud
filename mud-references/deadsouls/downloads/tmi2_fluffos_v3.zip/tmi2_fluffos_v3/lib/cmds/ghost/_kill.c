 
//	File	:  /cmds/ghost/_kill.c
//	Creator	:  Watcher@TMI  (04/03/93)
//
//	Just an interesting filler command for ghosts. :)
 
#include <mudlib.h>

inherit DAEMON ;
 
int cmd_kill() {

   write("Thou art a ghost ... how can you kill anyone?\n");

return 1; }
 
