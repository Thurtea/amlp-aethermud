 
//	File	:  /cmds/ghost/_passwd.c
//	Creator	:  Watcher@TMI  (4/11/93)
//
//	Sorry ... Ghosts can't change the users password.

#include <mudlib.h>

inherit DAEMON ;

int cmd_passwd() {

   write("You must be in your normal mortal form to change your password.\n");
 
return 1; } 

