// _pray.c
// This command notifies the player that he has to be in the cemetery to
// revive himself. The "pray" command in the cemetery will override this
// command.
// Written by Mobydick, 11-14-92.

#include <mudlib.h>

inherit DAEMON ;
int cmd_pray() {
	write ("You have to be in the cemetery to be revived.\n") ;
	return 1 ;
}
