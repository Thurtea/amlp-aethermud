
//	File	:  /cmds/ghost/_shout.c
//	Creator	:  Watcher@TMI  (4/11/93)
//
//	Poor ghosts ... they can't even shout. :)

#include <mudlib.h>

inherit DAEMON ;

int cmd_shout() {

   write("You strive to shout ... alas, no sound can you make.\n");
   write ("If you need to reach a wizard, you can use wizcall.\n") ;

return 1; }
 
