 
//	File	:  /cmds/ghost/_who.c
//	Creator	:  Watcher  (04/11/93)
//
//	Yet another bridge to the standard user who command.

#include <mudlib.h>
#include <commands.h>

inherit DAEMON ;

int cmd_who(string str) {  return (int)CMD_WHO->cmd_who(str);  }
 
