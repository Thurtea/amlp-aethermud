 
//	File	:  cmds/xtra/_chsh.c
//	Creator	:  Watcher @ TMI
//
//	Command used to set user shell from choices found in
//	reserved SHELL directory.
 
#include <mudlib.h>

inherit DAEMON ;
 
#define SHELL_LIST	"/adm/etc/shells"
#define NAME		(string) this_player()->query("cap_name")
 
#define SYNTAX	"Syntax: chsh [shell | ?]\n"
 
static string get_shell();
static int input_shell(string str);
static int list_shells();
static int load_shells();
 
string *SHELLS;
 
int cmd_chsh(string str) {
 
   if(!SHELLS)	load_shells();
 
   if(str == "?")  return list_shells();
 
   if(str && str != "")  return input_shell(str);
 
   write("Changing login shell for " + NAME + ".\nShell [" +
	 get_shell() + "]: ");
   input_to("input_shell");
 
return 1; }
 
static int input_shell(string str) {
   object shell;
   string old_shell;
   int loop;

   if(!str || str == "") {
   write("Login shell unchanged.\n");
   return 1; }
 
   old_shell = (string) this_player()->query("shell");
 
   if(str == "none")  str = 0;
   else {
     if (str[<2..<1] != ".c")  str += ".c";
     if(member_array(str, SHELLS) == -1) {
       write("Invalid shell selection, shell unchanged.\n");
       write(list_shells());
       return 1;
     }
   }

   if((string)this_player()->query("shell") == str) {
   write("Login shell unchanged.\n");
   return 1; }
 
   this_player()->set("shell", str);
   if(!str)  write("Login shell removed.\n");
   else write("Login shell changed.\n");
 
   shell = present("shell", this_player());
   if(shell && (base_name(shell) + ".c") == old_shell)  shell->remove();

   if(str && catch(clone_object(str)->move(this_player())))
   write("Chsh:  Error in shell creation.\n");
 
return 1; }
 
static string get_shell() {
   string tmp;
 
   tmp = (string)this_player()->query("shell");
   if(!tmp || tmp == "")  tmp = "none";
 
return tmp;  }
 
static int load_shells() {
   string list;
   int loop;

   list = read_file(SHELL_LIST);
   if(!list)  return 0;
 
   SHELLS = explode(list, "\n");
 
   for(loop=sizeof(SHELLS)-1; loop>-1; loop--)
   if(SHELLS[loop][0] == '#' || SHELLS[loop] == "")
	SHELLS = exclude_array(SHELLS, loop);

return 1; }
 
static int list_shells() {
   int loop;
 
   write("Available shell environments:\t");
 
   for(loop=0; loop<sizeof(SHELLS); loop++) {
        if(loop)  write("\t\t\t\t");
        write(SHELLS[loop] + "\n"); 
   }
 
   write("\t\t\t\tnone\n\n");
 
return 1; }
 
string help() {
 
   return(SYNTAX+"\n"+@HELP
This command allows a user to change their shell working environment.
The choices can be listed with "?" as a shell argument.

See also: shell, term
HELP
  );
}
 
