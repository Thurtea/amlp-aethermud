// Comments and credits as per praise, bug, idea and query.
#include <commands.h> 
inherit CMD_PRAISE;
int cmd_typo( string a ) { return cmd_report( a ); }
create() { ::create(); report_type = "typo"; report_file = "TYPOS"; }
