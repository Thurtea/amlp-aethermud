// the "arch" command. 
// basically, just a frontend to the "arch()" efun.
// Buddha@tmi-2 is responsible for whipping this command up. wow.
// 'twas done on 3/1/93

#include <mudlib.h>

inherit DAEMON;


int cmd_arch() {
	write(arch() + "\n");
	return 1;
}
