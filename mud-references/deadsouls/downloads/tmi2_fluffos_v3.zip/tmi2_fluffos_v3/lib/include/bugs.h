/* These are only used once, so we #define them */
#define RESTORE_BTI  "/data/bugs"
#define BTI_DATA_FILE  "data/bugs"

