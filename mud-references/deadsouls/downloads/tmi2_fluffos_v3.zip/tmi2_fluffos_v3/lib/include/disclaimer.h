/*
//  the Standard Disclaimer
//                         (as written by Pallando for LPC coders)
//
//  Be warned, the file that includes this disclaimer is not perfect.
//  It may have no documentation, commenting, indentation or error checking.
//  It may have bugs, security loop holes, inefficiencies and bad syntax.
//  There may be typos, incorrect credits, misfeatures or unfinished code.
//  You use, install or retain any file that includes this disclaimer
//              ***   AT  YOUR  OWN  RISK   ***
//  Due to conditions at the time of writing, the coder takes no responsibility
//  if Bad Things happen, your disc gets wiped, the sysop kicks your mud out,
//  the CIA investigate your mother, aliens flood half America, or the whole
//  file was a terrible idea to start with.  In particular, the coder takes no
//  responsibility for any imperfections warned of above or correcting them.
//  In fact the only thing guaranteed is that the coder isn't malicious.
*/
