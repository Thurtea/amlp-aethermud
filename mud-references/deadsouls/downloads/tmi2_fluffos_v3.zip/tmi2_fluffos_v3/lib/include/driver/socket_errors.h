/*
 * socket_errors.h - [OBSOLETE - use socket_err.h instead]
 */
#include <driver/socket_err.h>
