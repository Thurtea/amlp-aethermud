#define BOGUS_EXITS ({ "north", "south", "east", "west", "up", "down",    \
                      "northeast", "northwest", "southeast", "southwest", \
                      "in", "out", "enter", "exit", })

#define BOGUS_EXIT_MSG "You can't go that way.\n"

