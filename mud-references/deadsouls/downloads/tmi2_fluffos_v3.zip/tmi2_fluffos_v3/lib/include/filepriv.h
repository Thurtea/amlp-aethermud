#define NONE 0
#define READ 1
#define WRITE 2
