 
//  File  :  /include/invis.h
//
//  User invisibility level settings
 
#define ROOM_INVIS 	1
#define IO_INVIS 	2
#define WHO_INVIS 	4
#define NAME_INVIS 	8

