//  Undefine this if you don't want languages.

#define LANGUAGES

#define LANGUAGE_DEFAULT_SCORE 15

