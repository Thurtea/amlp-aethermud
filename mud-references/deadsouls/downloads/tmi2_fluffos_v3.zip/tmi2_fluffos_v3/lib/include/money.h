 
//  File  :  /include/money.h
//
//  Standard mudlib money system defines
 
#define STORAGE 	"/std/shop/storeroom.c"
#define CENTSTORE 	"/std/shop/warehouse.c"
#define BANK_CARD_FILE 	"/std/bank_card"
#define COINS 		"/std/coins"
#define SHOP_SALES_FRAC 3/4
 
