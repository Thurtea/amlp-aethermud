#ifndef	I3_MODULES
#define I3_MODULES	"/adm/daemons/network/I3/"
#define	I3_AUTH		"/adm/daemons/network/I3/auth"
#define	I3_CHANNEL	"/adm/daemons/network/I3/channel"
#define	I3_FINGER	"/adm/daemons/network/I3/finger"
#define	I3_LOCATE	"/adm/daemons/network/I3/locate"
#define	I3_TELL		"/adm/daemons/network/I3/tell"
#define	I3_WHO		"/adm/daemons/network/I3/who"
#endif
