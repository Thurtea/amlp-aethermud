 
//  File  :  /include/news.h
//
//  New System file location defines
 
#define NEWS_DIR	"/adm/news"
#define NEWS_D		"/adm/daemons/news"
 
