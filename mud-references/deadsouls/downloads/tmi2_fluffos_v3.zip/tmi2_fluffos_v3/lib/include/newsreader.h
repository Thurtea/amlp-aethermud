// #defines for the newsreader system

#define SAVE_FILE "/data/adm/daemons/news"
#define ARCHIVE_DAYS 14
#define ARCHIVE_DIR "/data/adm/daemons/news/archives"
#define NEWS_OBJ "/std/rn"
