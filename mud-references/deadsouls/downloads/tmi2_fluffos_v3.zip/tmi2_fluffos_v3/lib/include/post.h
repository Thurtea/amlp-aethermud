#define TRUSTED_MAILERS ({ "/adm/daemons/mail_serv", "/adm/obj/post" })
#define POST_ID "imaginary mailer"
#define POST_PROMPT "% "
#define POST_USER_HELP "/doc/post/user"
#define POST_IMMORTAL_HELP "/doc/post/creator"
#define DIR_POSTAL "/data/post"
#define DIR_LETTERS "/data/letters"
