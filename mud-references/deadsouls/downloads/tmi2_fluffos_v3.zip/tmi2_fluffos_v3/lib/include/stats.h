#define STAT_NUMBER	6

#define STAT_STR	0
#define STAT_INT	1
#define STAT_CON	2
#define STAT_DEX	3
#define STAT_PIE   4
#define STAT_PSI   5

#define STAT_NAMES	({ "strength", "intelligence",\
			       "constitution", "dexterity", "Piety", "Psi" })
