//This file was intended to be a bit more.
//

//This switch turns off all socket usage.
#define INTERMUD
