 
//  File  :  /include/uid.h
//
//  Mudlib global uid settings
 
#ifndef ROOT_UID
#define ROOT_UID "Root"
#define BACKBONE_UID "Backbone"
#endif

