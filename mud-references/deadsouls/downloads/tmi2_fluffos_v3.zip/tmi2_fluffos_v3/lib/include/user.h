 
//  File  :  /include/user.h
//
//  The specific user body inherits (Not used by MONSTER or GHOST)
// The #defines are in user2.h, so they may be included without
// inheriting all this code.
 
inherit "/std/user/tsh.c";
inherit "/std/user/autoload.c";
inherit "/std/user/save.c";
inherit "/std/user/bitflags.c";
// Moby thinks we may not need this anymroe.
//inherit "/std/user/team.c" ;
 
