#define VIRTUAL_SERVERS "/adm/daemons/virtual/"
