inherit "std/object/ob_logic";
#include "/std/object/prop.c"
