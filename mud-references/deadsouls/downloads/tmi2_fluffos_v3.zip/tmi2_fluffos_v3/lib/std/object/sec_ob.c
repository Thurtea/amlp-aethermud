inherit "std/object/ob_logic";
#define SECURE
#include "/std/object/prop.c"
